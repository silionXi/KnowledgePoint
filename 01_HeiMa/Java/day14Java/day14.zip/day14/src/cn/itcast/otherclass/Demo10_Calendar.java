package cn.itcast.otherclass;

import java.util.Calendar;

public class Demo10_Calendar {

	/**
	 * @param args
	 * public void add(int field,int amount)
	 * public final void set(int year,int month,int date)
	 */
	public static void main(String[] args) {
		//demo1();
		Calendar c = Calendar.getInstance();
		//c.add(Calendar.MONTH, -3);					//(int field,int amount)amout������ǰ��������ֶ����ӻ����(����������)
		//c.set(Calendar.YEAR, 2000);
		c.set(2008, 2, 8);
		System.out.println(c.get(Calendar.YEAR));
		System.out.println(c.get(Calendar.MONTH) + 1);
		System.out.println(c.get(Calendar.DAY_OF_MONTH));
	}

	public static void demo1() {
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);			//ͨ��ָ�����ֶλ�ȡ����ֵ
		System.out.println(year);
		int month = c.get(Calendar.MONTH);
		System.out.println(month + 1);
		int day = c.get(Calendar.DAY_OF_MONTH);
		System.out.println(day);
	}

}
