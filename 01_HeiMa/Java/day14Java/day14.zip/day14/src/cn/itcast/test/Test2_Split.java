package cn.itcast.test;

public class Test2_Split {

	/**
	 * @param args
	 * a:�и�
		�����밴�յ����и "sdqqfgkkkhjppppkl";
	 */
	public static void main(String[] args) {
		String regex = "(.)\\1+";
		String s = "sdqqfgkkkhjppppkl";
		String[] arr = s.split(regex);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

}
