package cn.itcast.regex;

public class Demo4_Regex {

	/**
	 * 	Greedy ������ 
		X? X��һ�λ�һ��Ҳû�� 
		X* X����λ��� 
		X+ X��һ�λ��� 
		X{n} X��ǡ�� n �� 
		X{n,} X������ n �� 
		X{n,m} X������ n �Σ����ǲ����� m �� 

	 */
	public static void main(String[] args) {
		//demo1();
		//demo2();
		//demo3();
		//demo4();
		//demo5();
		//demo6();

	}

	public static void demo6() {
		String regex = "[abc]{5,15}";
		System.out.println("abcba".matches(regex));
		System.out.println("abcbaaaaaaaaaaa".matches(regex));
		System.out.println("aaaa".matches(regex));
		System.out.println("aaaaaaaaaaaaaaaaa".matches(regex));
	}

	public static void demo5() {
		String regex = "[abc]{5,}";
		System.out.println("abcba".matches(regex));
		System.out.println("abcbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb".matches(regex));
	}

	public static void demo4() {
		String regex = "[abc]{5}";
		System.out.println("aaaa".matches(regex));
		System.out.println("aaaaa".matches(regex));
		System.out.println("aaaaaa".matches(regex));
		System.out.println("abcba".matches(regex));
	}

	public static void demo3() {
		String regex = "[abc]+";
		System.out.println("".matches(regex));
		System.out.println("aaaaaaaaaaaaaaaa".matches(regex));
		System.out.println("aaaabbbbccccccccccc".matches(regex));
		System.out.println("d".matches(regex));
	}

	public static void demo2() {
		String regex = "[abc]*";
		System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaa".matches(regex));
		System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbb".matches(regex));
		System.out.println("dddddd".matches(regex));
	}

	public static void demo1() {
		String regex = "[abc]?";					//һ�λ�һ��Ҳû�� 
		System.out.println("a".matches(regex));
		System.out.println("d".matches(regex));
		System.out.println("".matches(regex));
		System.out.println("ab".matches(regex));
	}

}
