package cn.itcast.otherclass;

import cn.itcast.bean.Person;

public class Demo03_System {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//demo1();
		//demo2();
		long start = System.currentTimeMillis();
		
		for(int i = 0; i < 100000; i++) {
			System.out.print("*");
		}
		long end = System.currentTimeMillis();
		System.out.println(end - start);
	}

	public static void demo2() {
		Person p1 = new Person("����", 23);
		System.out.println(p1);
		
		System.exit(0);						//�˳�jvm�����
		Person p2 = new Person("����", 24);
		System.out.println(p2);
	}

	public static void demo1() {
		Person p = new Person("����", 23);
		System.out.println(p);
		p = null;
		System.gc();					//������������
	}

}
