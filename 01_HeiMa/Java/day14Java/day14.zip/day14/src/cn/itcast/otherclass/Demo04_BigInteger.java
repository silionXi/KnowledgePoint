package cn.itcast.otherclass;

import java.math.BigInteger;

public class Demo04_BigInteger {

	/**
	 * * public BigInteger add(BigInteger val)
	* public BigInteger subtract(BigInteger val)
	* public BigInteger multiply(BigInteger val)
	* public BigInteger divide(BigInteger val)
	* public BigInteger[] divideAndRemainder(BigInteger val)
	* 
	 */
	public static void main(String[] args) {
		BigInteger b1 = new BigInteger("100");
		BigInteger b2 = new BigInteger("2");
		//System.out.println(b1.add(b2));				//+
		//System.out.println(b1.subtract(b2));		//-
		//System.out.println(b1.multiply(b2));  		//*
		//System.out.println(b1.divide(b2));  		//��
		BigInteger[] arr = b1.divideAndRemainder(b2);	//�̺�����
		System.out.println(arr[0]);
		System.out.println(arr[1]);
	}

}
