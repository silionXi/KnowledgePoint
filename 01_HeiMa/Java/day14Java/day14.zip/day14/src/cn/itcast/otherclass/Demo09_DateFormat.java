package cn.itcast.otherclass;

import java.text.ParseException;
import java.util.Date;

public class Demo09_DateFormat {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {
		//demo1();
		String time = "2008��08��08��";
		Date d = Demo08_DateUtil.stringToDate(time, "yyyy��MM��dd��");
		System.out.println(d);
	}

	public static void demo1() {
		Date d = new Date();
		String time = Demo08_DateUtil.dateToString(d, "yyyy��MM��dd��");
		System.out.println(time);
	}

}
