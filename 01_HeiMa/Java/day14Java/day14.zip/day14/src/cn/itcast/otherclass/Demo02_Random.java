package cn.itcast.otherclass;

import java.util.Random;

public class Demo02_Random {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Random r = new Random();
		Random r = new Random(1111);				//ͨ��������������
		
		for(int i = 0; i < 10; i++) {
			//System.out.println(r.nextInt());
			System.out.println(r.nextInt(10));
		}
	}

}
