package cn.itcast.arrays;

import java.util.Arrays;

public class Demo4_Arrays {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//int[] arr = {};
		//Arrays.sort(arr);
		//System.out.println(Arrays.toString(arr));
		
		int[] arr2 = {11,22,33,44,55,66,77};
		System.out.println(Arrays.binarySearch(arr2, 22));
		System.out.println(Arrays.binarySearch(arr2, 66));
		System.out.println(Arrays.binarySearch(arr2, 88));
		System.out.println(Arrays.binarySearch(arr2, 9));
		System.out.println(Arrays.binarySearch(arr2, 24));
	}
	
	/*
	 * public static String toString(int[] a) {	//{1,2,3}
        if (a == null)							//a = null
            return "null";						//ֱ�ӷ���null
        int iMax = a.length - 1;				//��¼ס�������ֵ
        if (iMax == -1)							//�������Ϊ��
            return "[]";						//����[]

        StringBuilder b = new StringBuilder();	//����StringBuilder����
        b.append('[');							//����[
        for (int i = 0; ; i++) {				//[1, 2, 3]
            b.append(a[i]);
            if (i == iMax)
                return b.append(']').toString();
            b.append(", ");
        }
    }
	 */
}
